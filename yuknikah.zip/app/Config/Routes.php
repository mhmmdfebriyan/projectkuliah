<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('create-db', function () {
    $forge = \Config\Database::forge();
    if ($forge->createDatabase('yuknikah')) {
        echo 'Database created!';
    }
});

$routes->get('login', 'Auth::login');
$routes->post('auth/loginProcess', 'Auth::loginProcess');
$routes->get('auth/loginProcess', 'Auth::loginProcess');
$routes->post('auth/logout', 'Auth::logout');
$routes->get('auth/logout', 'Auth::logout');

$routes->get('home', 'Home::index');
// $routes->get('', 'Home::index');
$routes->addRedirect('/', 'home');

$routes->get('acara', 'Acara::index');
$routes->get('acara/add', 'Acara::create');
$routes->post('acara', 'Acara::store');
$routes->get('acara/edit/(:num)', 'Acara::edit/$1');
$routes->put('acara/(:any)', 'Acara::update/$1');
$routes->delete('acara/(:segment)', 'Acara::destroy/$1');

$routes->get('groups/trash', 'Groups::trash');
$routes->post('groups/trash', 'Groups::trash');
$routes->get('groups/restore/(:any)', 'Groups::restore/$1');
$routes->post('groups/restore/(:any)', 'Groups::restore/$1');
$routes->get('groups/restore', 'Groups::restore');
$routes->post('groups/restore', 'Groups::restore');
$routes->delete('groups/delete2/(:any)', 'Groups::delete2/$1');
$routes->post('groups/delete2/(:any)', 'Groups::delete2/$1');
$routes->delete('groups/delete2', 'Groups::delete2');
$routes->post('groups/delete2', 'Groups::delete2');
$routes->presenter('groups', ['filter' => 'isLoggedIn']);

$routes->get('contacts/export', 'Contacts::export');

$routes->post('contacts/edit', 'Contacts::update/$1');
$routes->delete('contacts/delete/(:any)', 'Contacts::delete/$1');
$routes->post('contacts/delete/(:any)', 'Contacts::delete/$1');
$routes->post('contacts/(:any)', 'Contacts::delete/$1');

$routes->resource('contacts', ['filter' => 'isLoggedIn']);
