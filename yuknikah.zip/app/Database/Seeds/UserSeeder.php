<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    // {
    //     // untuk 1 data
    //     $data = [
    //         'name_user' => 'Administrator',
    //         'email_user' => 'dev.febriyanlua19@gmail.com',
    //         'password_user' => password_hash('12345', PASSWORD_BCRYPT),
    //     ];
    //     $this->db->table('users')->insert($data);
    // }

    {
        // untuk multi data
        $data = [
            [
                'name_user' => 'Muhammad Febriyan Lua',
                'email_user' => 'mfebriyan@gmail.com',
                'password_user' => password_hash('12345', PASSWORD_BCRYPT),
            ],
            [
                'name_user' => 'Nurmira Ahmad',
                'email_user' => 'miraahmad@gmail.com',
                'password_user' => password_hash('nurmira', PASSWORD_BCRYPT),
            ],
        ];
        $this->db->table('users')->insertBatch($data);
    }
}
